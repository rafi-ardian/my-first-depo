package projectccit;

import frame.startPanel;

public class ProjectCCIT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        startPanel start=new startPanel();
        
        start.setVisible(true);
        start.setLocationRelativeTo(start);
    }
    
}
