
package function;

import frame.chicken1;


public class counterAbstract extends counter2 {
    @Override
    String counter(){
        chicken1 c=new chicken1();
        
        int Counter = 3;
        Counter=Counter-1;
        return null;
    }
}
