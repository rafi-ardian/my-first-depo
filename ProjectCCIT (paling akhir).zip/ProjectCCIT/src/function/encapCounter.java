package function;


public class encapCounter {
    int counter(){
        int Counter = 3;
        Counter=Counter-1;
        return Counter;
    }
}
